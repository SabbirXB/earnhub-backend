# 🚀 EarnHub Backend API

Complete backend server for EarnHub - A task-based earning platform where users complete surveys, offers, and simple tasks to earn money.

## 📋 Table of Contents

- [Features](#features)
- [Tech Stack](#tech-stack)
- [Quick Start](#quick-start)
- [Installation](#installation)
- [Configuration](#configuration)
- [API Documentation](#api-documentation)
- [Database Schema](#database-schema)
- [Deployment](#deployment)
- [Security](#security)

## ✨ Features

✅ User authentication (Register, Login, JWT)  
✅ Task management system  
✅ Balance & transaction tracking  
✅ Withdrawal processing  
✅ Referral system  
✅ Daily streak bonuses  
✅ Email notifications  
✅ Payment gateway integration (PayPal, Stripe)  
✅ Admin panel API  
✅ Rate limiting & security  
✅ File uploads (profile pictures)  

## 🛠 Tech Stack

- **Backend**: Node.js + Express.js
- **Database**: MongoDB (Mongoose ODM)
- **Authentication**: JWT (JSON Web Tokens)
- **Payments**: PayPal Payouts, Stripe
- **Email**: Nodemailer
- **File Upload**: Multer + Cloudinary
- **Security**: Helmet, CORS, Rate Limiting
- **Validation**: Express Validator

## 🚀 Quick Start

### Prerequisites

- Node.js (v14 or higher)
- MongoDB (local or MongoDB Atlas)
- npm or yarn

### Installation

1. **Clone the repository**
```bash
git clone https://github.com/yourusername/earnhub-backend.git
cd earnhub-backend
```

2. **Install dependencies**
```bash
npm install
```

3. **Set up environment variables**
```bash
cp .env.example .env
# Edit .env and add your configuration
```

4. **Start MongoDB** (if running locally)
```bash
mongod
```

5. **Run the server**
```bash
# Development mode (with auto-reload)
npm run dev

# Production mode
npm start
```

Server will be running at: `http://localhost:5000`

## ⚙️ Configuration

### Environment Variables

Create a `.env` file in the root directory with the following variables:

```env
NODE_ENV=development
PORT=5000
MONGODB_URI=mongodb://localhost:27017/earnhub

JWT_SECRET=your_secret_key_here
JWT_EXPIRE=7d

PAYPAL_CLIENT_ID=your_paypal_client_id
PAYPAL_CLIENT_SECRET=your_paypal_secret

# See .env.example for complete configuration
```

### Database Setup

The database will be automatically created when you first run the server. No manual setup required!

**Optional**: Seed sample data
```bash
npm run seed
```

## 📚 API Documentation

### Base URL
```
http://localhost:5000/api
```

### Authentication Endpoints

#### Register User
```http
POST /api/auth/register
Content-Type: application/json

{
  "email": "user@example.com",
  "username": "johndoe",
  "password": "password123",
  "referralCode": "ABCD1234" // optional
}
```

**Response:**
```json
{
  "success": true,
  "message": "Registration successful!",
  "data": {
    "user": {
      "id": "64f5...",
      "email": "user@example.com",
      "username": "johndoe",
      "emailVerified": false
    },
    "token": "eyJhbGciOiJIUzI1NiIs...",
    "balance": {
      "available": 5.00,
      "pending": 0,
      "totalEarned": 5.00
    }
  }
}
```

#### Login
```http
POST /api/auth/login
Content-Type: application/json

{
  "email": "user@example.com",
  "password": "password123"
}
```

#### Refresh Token
```http
POST /api/auth/refresh-token
Content-Type: application/json

{
  "refreshToken": "your_refresh_token_here"
}
```

### User Endpoints

#### Get User Profile
```http
GET /api/users/profile
Authorization: Bearer {token}
```

#### Update Profile
```http
PUT /api/users/profile
Authorization: Bearer {token}
Content-Type: application/json

{
  "firstName": "John",
  "lastName": "Doe",
  "country": "US"
}
```

#### Get Balance
```http
GET /api/users/balance
Authorization: Bearer {token}
```

**Response:**
```json
{
  "success": true,
  "data": {
    "availableBalance": 47.35,
    "pendingBalance": 12.80,
    "totalEarned": 294.65,
    "totalWithdrawn": 234.50,
    "currency": "USD"
  }
}
```

### Task Endpoints

#### Get All Tasks
```http
GET /api/tasks?category=survey&difficulty=easy&hot=true
Authorization: Bearer {token}
```

**Query Parameters:**
- `category`: survey, offer, app, task
- `difficulty`: easy, medium, hard
- `hot`: true/false
- `sortBy`: reward, new, priority
- `limit`: number (default: 50)

#### Get Task Details
```http
GET /api/tasks/:taskId
Authorization: Bearer {token}
```

#### Start Task
```http
POST /api/tasks/:taskId/start
Authorization: Bearer {token}
```

#### Complete Task
```http
POST /api/tasks/:taskId/complete
Authorization: Bearer {token}
Content-Type: application/json

{
  "proof": "screenshot_url or completion code"
}
```

### Withdrawal Endpoints

#### Request Withdrawal
```http
POST /api/withdrawals/request
Authorization: Bearer {token}
Content-Type: application/json

{
  "amount": 25.00,
  "paymentMethod": "paypal",
  "paymentDetails": {
    "email": "user@paypal.com"
  }
}
```

#### Get Withdrawal History
```http
GET /api/withdrawals/history
Authorization: Bearer {token}
```

### Referral Endpoints

#### Get Referral Code
```http
GET /api/referrals/code
Authorization: Bearer {token}
```

#### Get Referral Stats
```http
GET /api/referrals/stats
Authorization: Bearer {token}
```

## 🗄 Database Schema

### Users Collection
```javascript
{
  email: String (unique),
  username: String (unique),
  password: String (hashed),
  firstName: String,
  lastName: String,
  country: String,
  emailVerified: Boolean,
  accountStatus: String, // active, suspended, banned
  balance: {
    available: Number,
    pending: Number,
    totalEarned: Number,
    totalWithdrawn: Number
  },
  referralCode: String (unique),
  referredBy: ObjectId,
  dailyStreak: {
    current: Number,
    longest: Number,
    lastActivity: Date
  },
  createdAt: Date,
  updatedAt: Date
}
```

### Tasks Collection
```javascript
{
  title: String,
  description: String,
  category: String, // survey, offer, app, task
  rewardAmount: Number,
  timeEstimate: Number,
  difficulty: String, // easy, medium, hard
  maxCompletions: Number,
  currentCompletions: Number,
  isActive: Boolean,
  isHot: Boolean,
  expiresAt: Date,
  createdAt: Date,
  updatedAt: Date
}
```

## 🚢 Deployment

### Deploy to Heroku

1. **Install Heroku CLI**
```bash
npm install -g heroku
```

2. **Login to Heroku**
```bash
heroku login
```

3. **Create Heroku app**
```bash
heroku create earnhub-api
```

4. **Add MongoDB addon**
```bash
heroku addons:create mongolab:sandbox
```

5. **Set environment variables**
```bash
heroku config:set JWT_SECRET=your_secret_here
heroku config:set NODE_ENV=production
```

6. **Deploy**
```bash
git push heroku main
```

### Deploy to Railway

1. Push code to GitHub
2. Go to [railway.app](https://railway.app)
3. Click "New Project" → "Deploy from GitHub"
4. Select your repository
5. Add environment variables
6. Deploy!

### Deploy to Render

1. Push code to GitHub
2. Go to [render.com](https://render.com)
3. Click "New" → "Web Service"
4. Connect your repository
5. Add environment variables
6. Deploy!

## 🔒 Security Best Practices

✅ **Implemented:**
- Password hashing with bcrypt
- JWT authentication
- Rate limiting
- Input validation
- CORS protection
- Helmet security headers
- SQL injection prevention
- XSS protection

⚠️ **Recommendations:**
- Use HTTPS in production
- Enable MongoDB authentication
- Set strong JWT secrets
- Regular security audits
- Keep dependencies updated
- Implement 2FA for admin accounts

## 📝 Project Structure

```
earnhub-backend/
├── models/
│   ├── User.js
│   ├── Task.js
│   ├── Withdrawal.js
│   └── Transaction.js
├── routes/
│   ├── auth.js
│   ├── users.js
│   ├── tasks.js
│   ├── withdrawals.js
│   └── admin.js
├── middleware/
│   ├── auth.js
│   ├── validation.js
│   └── errorHandler.js
├── services/
│   ├── emailService.js
│   ├── paymentService.js
│   └── uploadService.js
├── utils/
│   ├── helpers.js
│   └── validators.js
├── .env.example
├── package.json
├── server.js
└── README.md
```

## 🧪 Testing

```bash
# Run tests
npm test

# Run tests in watch mode
npm run test:watch
```

## 📊 Monitoring

Recommended monitoring tools:
- **Error Tracking**: Sentry
- **Performance**: New Relic
- **Uptime**: UptimeRobot
- **Logs**: Loggly or Papertrail

## 🤝 Contributing

1. Fork the repository
2. Create a feature branch (`git checkout -b feature/amazing-feature`)
3. Commit your changes (`git commit -m 'Add amazing feature'`)
4. Push to the branch (`git push origin feature/amazing-feature`)
5. Open a Pull Request

## 📄 License

This project is licensed under the MIT License.

## 💬 Support

For support and questions:
- Email: support@earnhub.com
- Discord: [Join our community]
- Documentation: [docs.earnhub.com]

## 🗺 Roadmap

- [ ] Add cryptocurrency withdrawal support
- [ ] Implement KYC verification
- [ ] Add mobile app API endpoints
- [ ] Multi-language support
- [ ] Advanced analytics dashboard
- [ ] Automated task verification
- [ ] Gamification features
- [ ] Social sharing features

## ⚡ Performance Tips

1. Enable MongoDB indexes
2. Use Redis for caching
3. Implement pagination
4. Optimize database queries
5. Use CDN for static assets
6. Enable gzip compression
7. Implement connection pooling

## 🎯 Getting Help

If you encounter any issues:

1. Check the [FAQ](#)
2. Search existing [issues](https://github.com/yourusername/earnhub-backend/issues)
3. Create a new issue with details
4. Join our Discord community

---

**Built with ❤️ by the EarnHub Team**

⭐ Star this repo if you find it helpful!
