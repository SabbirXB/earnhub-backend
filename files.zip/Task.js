// ============================================================================
// TASK MODEL
// ============================================================================

const mongoose = require('mongoose');

const taskSchema = new mongoose.Schema({
    title: {
        type: String,
        required: [true, 'Task title is required'],
        trim: true,
        maxlength: [200, 'Title cannot exceed 200 characters']
    },
    description: {
        type: String,
        required: [true, 'Task description is required'],
        trim: true
    },
    category: {
        type: String,
        required: [true, 'Task category is required'],
        enum: ['survey', 'offer', 'app', 'task'],
        lowercase: true
    },
    rewardAmount: {
        type: Number,
        required: [true, 'Reward amount is required'],
        min: [0.01, 'Reward must be at least $0.01'],
        max: [1000, 'Reward cannot exceed $1000']
    },
    timeEstimate: {
        type: Number, // in minutes
        required: [true, 'Time estimate is required'],
        min: [1, 'Time estimate must be at least 1 minute']
    },
    difficulty: {
        type: String,
        enum: ['easy', 'medium', 'hard'],
        default: 'easy',
        lowercase: true
    },
    requirements: {
        type: String,
        trim: true
    },
    instructions: {
        type: String,
        trim: true
    },
    maxCompletions: {
        type: Number,
        default: 1000,
        min: [1, 'Must allow at least 1 completion']
    },
    currentCompletions: {
        type: Number,
        default: 0,
        min: 0
    },
    provider: {
        name: {
            type: String,
            trim: true
        },
        url: {
            type: String,
            trim: true
        },
        logo: {
            type: String,
            trim: true
        }
    },
    isActive: {
        type: Boolean,
        default: true
    },
    isHot: {
        type: Boolean,
        default: false
    },
    isFeatured: {
        type: Boolean,
        default: false
    },
    countryRestrictions: [{
        type: String,
        uppercase: true
    }], // Array of country codes
    ageRestriction: {
        min: {
            type: Number,
            default: 18
        },
        max: {
            type: Number
        }
    },
    deviceRequirement: {
        type: String,
        enum: ['any', 'mobile', 'desktop'],
        default: 'any'
    },
    expiresAt: {
        type: Date
    },
    priority: {
        type: Number,
        default: 0 // Higher number = higher priority
    },
    completionProofRequired: {
        type: Boolean,
        default: false
    },
    tags: [{
        type: String,
        lowercase: true,
        trim: true
    }],
    stats: {
        views: {
            type: Number,
            default: 0
        },
        starts: {
            type: Number,
            default: 0
        },
        completions: {
            type: Number,
            default: 0
        },
        averageCompletionTime: {
            type: Number, // in minutes
            default: 0
        }
    }
}, {
    timestamps: true
});

// ============================================================================
// INDEXES
// ============================================================================

taskSchema.index({ category: 1, isActive: 1 });
taskSchema.index({ rewardAmount: -1 });
taskSchema.index({ priority: -1 });
taskSchema.index({ isHot: 1, isActive: 1 });
taskSchema.index({ expiresAt: 1 });

// ============================================================================
// VIRTUAL PROPERTIES
// ============================================================================

// Check if task is available
taskSchema.virtual('isAvailable').get(function() {
    if (!this.isActive) return false;
    if (this.currentCompletions >= this.maxCompletions) return false;
    if (this.expiresAt && new Date() > this.expiresAt) return false;
    return true;
});

// Calculate completion rate
taskSchema.virtual('completionRate').get(function() {
    if (this.stats.starts === 0) return 0;
    return Math.round((this.stats.completions / this.stats.starts) * 100);
});

// ============================================================================
// METHODS
// ============================================================================

// Increment view count
taskSchema.methods.recordView = async function() {
    this.stats.views += 1;
    await this.save();
};

// Record task start
taskSchema.methods.recordStart = async function() {
    this.stats.starts += 1;
    await this.save();
};

// Record task completion
taskSchema.methods.recordCompletion = async function(completionTime) {
    this.stats.completions += 1;
    this.currentCompletions += 1;
    
    // Update average completion time
    if (completionTime) {
        const totalTime = this.stats.averageCompletionTime * (this.stats.completions - 1);
        this.stats.averageCompletionTime = (totalTime + completionTime) / this.stats.completions;
    }
    
    await this.save();
};

// Check if user can access task
taskSchema.methods.canUserAccess = function(user) {
    // Check country restrictions
    if (this.countryRestrictions.length > 0 && user.country) {
        if (!this.countryRestrictions.includes(user.country.toUpperCase())) {
            return { allowed: false, reason: 'Not available in your country' };
        }
    }
    
    // Check age restrictions
    if (user.dateOfBirth) {
        const age = Math.floor((new Date() - new Date(user.dateOfBirth)) / 31557600000);
        if (age < this.ageRestriction.min) {
            return { allowed: false, reason: `Must be at least ${this.ageRestriction.min} years old` };
        }
        if (this.ageRestriction.max && age > this.ageRestriction.max) {
            return { allowed: false, reason: `Must be under ${this.ageRestriction.max} years old` };
        }
    }
    
    // Check if task is available
    if (!this.isAvailable) {
        return { allowed: false, reason: 'Task is no longer available' };
    }
    
    return { allowed: true };
};

// Get public task data
taskSchema.methods.getPublicData = function() {
    return {
        id: this._id,
        title: this.title,
        description: this.description,
        category: this.category,
        reward: this.rewardAmount,
        timeEstimate: this.timeEstimate,
        difficulty: this.difficulty,
        isHot: this.isHot,
        isFeatured: this.isFeatured,
        provider: this.provider,
        completionRate: this.completionRate,
        currentCompletions: this.currentCompletions,
        maxCompletions: this.maxCompletions,
        tags: this.tags
    };
};

// ============================================================================
// STATIC METHODS
// ============================================================================

// Get available tasks for user
taskSchema.statics.getAvailableTasks = async function(filters = {}) {
    const query = { 
        isActive: true,
        $expr: { $lt: ['$currentCompletions', '$maxCompletions'] }
    };
    
    // Add category filter
    if (filters.category) {
        query.category = filters.category;
    }
    
    // Add difficulty filter
    if (filters.difficulty) {
        query.difficulty = filters.difficulty;
    }
    
    // Add hot filter
    if (filters.hot === true) {
        query.isHot = true;
    }
    
    // Sorting
    let sort = {};
    if (filters.sortBy === 'reward') {
        sort.rewardAmount = -1;
    } else if (filters.sortBy === 'new') {
        sort.createdAt = -1;
    } else {
        sort.priority = -1; // Default: priority
    }
    
    const tasks = await this.find(query).sort(sort).limit(filters.limit || 50);
    return tasks;
};

// ============================================================================
// MIDDLEWARE
// ============================================================================

// Set expiresAt to 30 days from now if not set
taskSchema.pre('save', function(next) {
    if (!this.expiresAt && this.isNew) {
        this.expiresAt = new Date(Date.now() + 30 * 24 * 60 * 60 * 1000); // 30 days
    }
    next();
});

// ============================================================================
// EXPORT MODEL
// ============================================================================

const Task = mongoose.model('Task', taskSchema);

module.exports = Task;