// ============================================================================
// USER MODEL
// ============================================================================

const mongoose = require('mongoose');
const bcrypt = require('bcryptjs');

const userSchema = new mongoose.Schema({
    email: {
        type: String,
        required: [true, 'Email is required'],
        unique: true,
        lowercase: true,
        trim: true,
        match: [/^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/, 'Please enter a valid email']
    },
    username: {
        type: String,
        required: [true, 'Username is required'],
        unique: true,
        trim: true,
        minlength: [3, 'Username must be at least 3 characters'],
        maxlength: [30, 'Username cannot exceed 30 characters']
    },
    password: {
        type: String,
        required: [true, 'Password is required'],
        minlength: [6, 'Password must be at least 6 characters'],
        select: false // Don't include password in queries by default
    },
    firstName: {
        type: String,
        trim: true
    },
    lastName: {
        type: String,
        trim: true
    },
    phoneNumber: {
        type: String,
        trim: true
    },
    country: {
        type: String,
        trim: true
    },
    dateOfBirth: {
        type: Date
    },
    profilePicture: {
        type: String,
        default: ''
    },
    accountStatus: {
        type: String,
        enum: ['active', 'suspended', 'banned'],
        default: 'active'
    },
    emailVerified: {
        type: Boolean,
        default: false
    },
    kycVerified: {
        type: Boolean,
        default: false
    },
    role: {
        type: String,
        enum: ['user', 'admin', 'moderator'],
        default: 'user'
    },
    balance: {
        available: {
            type: Number,
            default: 0,
            min: 0
        },
        pending: {
            type: Number,
            default: 0,
            min: 0
        },
        totalEarned: {
            type: Number,
            default: 0,
            min: 0
        },
        totalWithdrawn: {
            type: Number,
            default: 0,
            min: 0
        }
    },
    referralCode: {
        type: String,
        unique: true
    },
    referredBy: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'User'
    },
    dailyStreak: {
        current: {
            type: Number,
            default: 0
        },
        longest: {
            type: Number,
            default: 0
        },
        lastActivity: {
            type: Date
        }
    },
    settings: {
        emailNotifications: {
            type: Boolean,
            default: true
        },
        newsletter: {
            type: Boolean,
            default: true
        },
        language: {
            type: String,
            default: 'en'
        }
    },
    lastLogin: {
        type: Date
    },
    ipAddress: {
        type: String
    }
}, {
    timestamps: true
});

// ============================================================================
// INDEXES
// ============================================================================

userSchema.index({ email: 1 });
userSchema.index({ username: 1 });
userSchema.index({ referralCode: 1 });

// ============================================================================
// PRE-SAVE MIDDLEWARE
// ============================================================================

// Hash password before saving
userSchema.pre('save', async function(next) {
    if (!this.isModified('password')) {
        return next();
    }
    
    try {
        const salt = await bcrypt.genSalt(10);
        this.password = await bcrypt.hash(this.password, salt);
        next();
    } catch (error) {
        next(error);
    }
});

// Generate referral code before saving
userSchema.pre('save', function(next) {
    if (!this.referralCode) {
        this.referralCode = generateReferralCode();
    }
    next();
});

// ============================================================================
// METHODS
// ============================================================================

// Compare password method
userSchema.methods.comparePassword = async function(candidatePassword) {
    try {
        return await bcrypt.compare(candidatePassword, this.password);
    } catch (error) {
        throw new Error(error);
    }
};

// Get public profile (without sensitive data)
userSchema.methods.getPublicProfile = function() {
    return {
        id: this._id,
        username: this.username,
        email: this.email,
        firstName: this.firstName,
        lastName: this.lastName,
        profilePicture: this.profilePicture,
        emailVerified: this.emailVerified,
        accountStatus: this.accountStatus,
        createdAt: this.createdAt
    };
};

// Update balance
userSchema.methods.updateBalance = async function(amount, type = 'add') {
    if (type === 'add') {
        this.balance.available += amount;
        this.balance.totalEarned += amount;
    } else if (type === 'subtract') {
        if (this.balance.available < amount) {
            throw new Error('Insufficient balance');
        }
        this.balance.available -= amount;
        this.balance.totalWithdrawn += amount;
    }
    
    await this.save();
    return this.balance;
};

// Update daily streak
userSchema.methods.updateStreak = async function() {
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    
    const lastActivity = this.dailyStreak.lastActivity 
        ? new Date(this.dailyStreak.lastActivity) 
        : null;
    
    if (lastActivity) {
        lastActivity.setHours(0, 0, 0, 0);
        const daysDiff = Math.floor((today - lastActivity) / (1000 * 60 * 60 * 24));
        
        if (daysDiff === 1) {
            // Continue streak
            this.dailyStreak.current += 1;
            if (this.dailyStreak.current > this.dailyStreak.longest) {
                this.dailyStreak.longest = this.dailyStreak.current;
            }
        } else if (daysDiff > 1) {
            // Streak broken
            this.dailyStreak.current = 1;
        }
        // If daysDiff === 0, same day, don't update
    } else {
        // First activity
        this.dailyStreak.current = 1;
        this.dailyStreak.longest = 1;
    }
    
    this.dailyStreak.lastActivity = new Date();
    await this.save();
    return this.dailyStreak;
};

// ============================================================================
// HELPER FUNCTIONS
// ============================================================================

function generateReferralCode() {
    const characters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
    let code = '';
    for (let i = 0; i < 8; i++) {
        code += characters.charAt(Math.floor(Math.random() * characters.length));
    }
    return code;
}

// ============================================================================
// EXPORT MODEL
// ============================================================================

const User = mongoose.model('User', userSchema);

module.exports = User;