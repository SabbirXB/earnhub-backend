// ============================================================================
// AUTHENTICATION ROUTES
// ============================================================================

const express = require('express');
const router = express.Router();
const jwt = require('jsonwebtoken');
const User = require('../models/User');
const { body, validationResult } = require('express-validator');

// ============================================================================
// VALIDATION MIDDLEWARE
// ============================================================================

const registerValidation = [
    body('email').isEmail().normalizeEmail().withMessage('Invalid email address'),
    body('username').trim().isLength({ min: 3, max: 30 }).withMessage('Username must be 3-30 characters'),
    body('password').isLength({ min: 6 }).withMessage('Password must be at least 6 characters')
];

const loginValidation = [
    body('email').isEmail().normalizeEmail().withMessage('Invalid email address'),
    body('password').notEmpty().withMessage('Password is required')
];

// ============================================================================
// HELPER FUNCTIONS
// ============================================================================

// Generate JWT token
const generateToken = (userId) => {
    return jwt.sign(
        { id: userId },
        process.env.JWT_SECRET || 'your-secret-key',
        { expiresIn: process.env.JWT_EXPIRE || '7d' }
    );
};

// Generate refresh token
const generateRefreshToken = (userId) => {
    return jwt.sign(
        { id: userId },
        process.env.REFRESH_TOKEN_SECRET || 'your-refresh-secret',
        { expiresIn: process.env.REFRESH_TOKEN_EXPIRE || '30d' }
    );
};

// ============================================================================
// POST /api/auth/register - User Registration
// ============================================================================

router.post('/register', registerValidation, async (req, res) => {
    try {
        // Check validation errors
        const errors = validationResult(req);
        if (!errors.isEmpty()) {
            return res.status(400).json({
                success: false,
                error: {
                    code: 'VALIDATION_ERROR',
                    message: errors.array()[0].msg
                }
            });
        }

        const { email, username, password, referralCode } = req.body;

        // Check if user already exists
        const existingUser = await User.findOne({ 
            $or: [{ email }, { username }] 
        });

        if (existingUser) {
            return res.status(400).json({
                success: false,
                error: {
                    code: 'USER_EXISTS',
                    message: existingUser.email === email 
                        ? 'Email already registered' 
                        : 'Username already taken'
                }
            });
        }

        // Check referral code if provided
        let referrer = null;
        if (referralCode) {
            referrer = await User.findOne({ referralCode });
            if (!referrer) {
                return res.status(400).json({
                    success: false,
                    error: {
                        code: 'INVALID_REFERRAL',
                        message: 'Invalid referral code'
                    }
                });
            }
        }

        // Create new user
        const newUser = new User({
            email,
            username,
            password,
            referredBy: referrer ? referrer._id : null,
            balance: {
                available: 5.00, // $5 signup bonus
                pending: 0,
                totalEarned: 5.00,
                totalWithdrawn: 0
            }
        });

        await newUser.save();

        // Give referrer bonus if applicable
        if (referrer) {
            // Add $1 referral bonus to referrer
            await referrer.updateBalance(1.00, 'add');
            
            // Create referral record (you'd need a Referral model for this)
            // await Referral.create({ referrerId: referrer._id, refereeId: newUser._id });
        }

        // Generate tokens
        const token = generateToken(newUser._id);
        const refreshToken = generateRefreshToken(newUser._id);

        // Send welcome email (implement email service)
        // await sendWelcomeEmail(newUser.email, newUser.username);

        res.status(201).json({
            success: true,
            message: 'Registration successful! Welcome to EarnHub!',
            data: {
                user: newUser.getPublicProfile(),
                token,
                refreshToken,
                balance: newUser.balance
            }
        });

    } catch (error) {
        console.error('Registration Error:', error);
        res.status(500).json({
            success: false,
            error: {
                code: 'REGISTRATION_FAILED',
                message: 'Registration failed. Please try again.'
            }
        });
    }
});

// ============================================================================
// POST /api/auth/login - User Login
// ============================================================================

router.post('/login', loginValidation, async (req, res) => {
    try {
        // Check validation errors
        const errors = validationResult(req);
        if (!errors.isEmpty()) {
            return res.status(400).json({
                success: false,
                error: {
                    code: 'VALIDATION_ERROR',
                    message: errors.array()[0].msg
                }
            });
        }

        const { email, password } = req.body;

        // Find user and include password field
        const user = await User.findOne({ email }).select('+password');

        if (!user) {
            return res.status(401).json({
                success: false,
                error: {
                    code: 'INVALID_CREDENTIALS',
                    message: 'Invalid email or password'
                }
            });
        }

        // Check if account is suspended or banned
        if (user.accountStatus !== 'active') {
            return res.status(403).json({
                success: false,
                error: {
                    code: 'ACCOUNT_SUSPENDED',
                    message: `Your account is ${user.accountStatus}`
                }
            });
        }

        // Verify password
        const isPasswordValid = await user.comparePassword(password);

        if (!isPasswordValid) {
            return res.status(401).json({
                success: false,
                error: {
                    code: 'INVALID_CREDENTIALS',
                    message: 'Invalid email or password'
                }
            });
        }

        // Update last login
        user.lastLogin = new Date();
        user.ipAddress = req.ip;
        await user.save();

        // Generate tokens
        const token = generateToken(user._id);
        const refreshToken = generateRefreshToken(user._id);

        res.json({
            success: true,
            message: 'Login successful',
            data: {
                user: user.getPublicProfile(),
                token,
                refreshToken,
                balance: user.balance
            }
        });

    } catch (error) {
        console.error('Login Error:', error);
        res.status(500).json({
            success: false,
            error: {
                code: 'LOGIN_FAILED',
                message: 'Login failed. Please try again.'
            }
        });
    }
});

// ============================================================================
// POST /api/auth/refresh-token - Refresh Access Token
// ============================================================================

router.post('/refresh-token', async (req, res) => {
    try {
        const { refreshToken } = req.body;

        if (!refreshToken) {
            return res.status(400).json({
                success: false,
                error: {
                    code: 'TOKEN_REQUIRED',
                    message: 'Refresh token is required'
                }
            });
        }

        // Verify refresh token
        const decoded = jwt.verify(
            refreshToken, 
            process.env.REFRESH_TOKEN_SECRET || 'your-refresh-secret'
        );

        // Generate new access token
        const newToken = generateToken(decoded.id);

        res.json({
            success: true,
            data: {
                token: newToken
            }
        });

    } catch (error) {
        console.error('Token Refresh Error:', error);
        res.status(401).json({
            success: false,
            error: {
                code: 'INVALID_TOKEN',
                message: 'Invalid or expired refresh token'
            }
        });
    }
});

// ============================================================================
// POST /api/auth/logout - User Logout
// ============================================================================

router.post('/logout', (req, res) => {
    // In a real application, you would blacklist the token
    // For now, just return success (client will delete token)
    res.json({
        success: true,
        message: 'Logout successful'
    });
});

// ============================================================================
// POST /api/auth/verify-email - Verify Email Address
// ============================================================================

router.post('/verify-email', async (req, res) => {
    try {
        const { token } = req.body;

        // Verify email token (implement your email verification logic)
        // This is a simplified version
        const decoded = jwt.verify(token, process.env.JWT_SECRET || 'your-secret-key');

        const user = await User.findById(decoded.id);

        if (!user) {
            return res.status(404).json({
                success: false,
                error: {
                    code: 'USER_NOT_FOUND',
                    message: 'User not found'
                }
            });
        }

        user.emailVerified = true;
        await user.save();

        res.json({
            success: true,
            message: 'Email verified successfully'
        });

    } catch (error) {
        console.error('Email Verification Error:', error);
        res.status(400).json({
            success: false,
            error: {
                code: 'VERIFICATION_FAILED',
                message: 'Email verification failed'
            }
        });
    }
});

// ============================================================================
// POST /api/auth/forgot-password - Request Password Reset
// ============================================================================

router.post('/forgot-password', async (req, res) => {
    try {
        const { email } = req.body;

        const user = await User.findOne({ email });

        if (!user) {
            // Don't reveal if email exists
            return res.json({
                success: true,
                message: 'If the email exists, a reset link has been sent'
            });
        }

        // Generate reset token
        const resetToken = generateToken(user._id);

        // Send password reset email (implement email service)
        // await sendPasswordResetEmail(user.email, resetToken);

        res.json({
            success: true,
            message: 'Password reset link sent to your email'
        });

    } catch (error) {
        console.error('Password Reset Error:', error);
        res.status(500).json({
            success: false,
            error: {
                code: 'RESET_FAILED',
                message: 'Failed to process password reset'
            }
        });
    }
});

// ============================================================================
// POST /api/auth/reset-password - Reset Password
// ============================================================================

router.post('/reset-password', async (req, res) => {
    try {
        const { token, newPassword } = req.body;

        // Verify reset token
        const decoded = jwt.verify(token, process.env.JWT_SECRET || 'your-secret-key');

        const user = await User.findById(decoded.id);

        if (!user) {
            return res.status(404).json({
                success: false,
                error: {
                    code: 'USER_NOT_FOUND',
                    message: 'User not found'
                }
            });
        }

        // Update password
        user.password = newPassword;
        await user.save();

        res.json({
            success: true,
            message: 'Password reset successful'
        });

    } catch (error) {
        console.error('Password Reset Error:', error);
        res.status(400).json({
            success: false,
            error: {
                code: 'RESET_FAILED',
                message: 'Password reset failed'
            }
        });
    }
});

// ============================================================================
// EXPORT ROUTER
// ============================================================================

module.exports = router;